#include "ShaderStruct.hlsli"

cbuffer externalData : register(b0)
{
    matrix world;
    matrix view;
    matrix projection;
    matrix worldInvTranspose;
  
};




VertexToPixel main( VertexShaderInput input )
{

    VertexToPixel output;

	// Calculate screen position of this vertex
    matrix wvp = mul(projection, mul(view, world));
    output.screenPosition = mul(wvp, float4(input.localPosition, 1.0f));

	// Pass other data through (for now)
    output.uv = input.uv;
    output.normal = normalize(mul((float3x3) worldInvTranspose, input.normal));
    output.tangent = normalize(mul((float3x3) world, input.tangent));
    output.worldPosition = mul(world, float4(input.localPosition, 1.0f)).xyz;

	return output;
}